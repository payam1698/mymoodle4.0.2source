Current version is 0.8.0

# Download latest stable version from https://github.com/php-ai/php-ml
# Remove all files but:
   * src/
   * LICENSE
# Copy content of src/ to /path/to/moodle/lib/mlbackend/php/phpml/src/Phpml
# Copy LICENSE file to /path/to/moodle/lib/mlbackend/php/phpml
