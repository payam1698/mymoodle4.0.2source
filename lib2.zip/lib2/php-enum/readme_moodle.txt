Instructions to import php-enum into Moodle:

1/ Download from https://github.com/myclabs/php-enum/releases

2/ Copy the LICENSE file and the src folder into the lib/php-enum folder

3/ Remove the src/PHPUnit folder, as it is not required
